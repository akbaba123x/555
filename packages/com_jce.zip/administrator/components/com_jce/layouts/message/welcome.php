<div class="alert alert-info" role="alert">
    <h2>Welcome to JCE Pro!</h2>
    <p>You will now need to add the Pro buttons you require to the editor toolbar of each profile in use.</p>
    <ol>
        <li>Go to <a href="index.php?option=com_jce&view=profiles"><u>Editor Profiles</u></a> and click on the name of a profile to edit it.</li>
        <li>Click on the Features & Layout tab, and scroll down to <strong>Current Editor Layout</strong></li>
        <li>Drag the buttons you require from the <strong>Available Buttons & Toolbars</strong> area into the <strong>Current Editor Layout</strong></li>
        <li>Click the <strong>Save</strong> button</li>
    </ol>
</div>