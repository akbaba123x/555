<?php

defined('JPATH_PLATFORM') or die;

JFormHelper::loadFieldClass('filetype');

class JFormFieldExtension extends JFormFieldFiletype
{

}